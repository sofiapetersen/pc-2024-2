package ast;


public class ETrue extends Exp{
	
	public ETrue()
	{
	  super();
	  
	} 

}
