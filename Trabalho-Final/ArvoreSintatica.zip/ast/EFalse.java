package ast;


public class EFalse extends Exp{
	
	public EFalse()
	{
	  super();
	  
	} 

}
